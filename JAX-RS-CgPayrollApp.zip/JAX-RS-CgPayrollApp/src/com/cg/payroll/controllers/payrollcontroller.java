package com.cg.payroll.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.xml.ws.Response;

public class payrollcontroller {
	
	@GET
	@Path("/hello")
	public String sayHello(){
		return "Hello World from restful Services";
	}

}
