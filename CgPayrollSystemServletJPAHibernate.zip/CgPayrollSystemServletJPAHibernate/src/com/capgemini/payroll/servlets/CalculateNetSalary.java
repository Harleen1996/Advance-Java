package com.capgemini.payroll.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.daoservices.AssociateDAO;
import com.capgemini.payroll.daoservices.AssociateDAOImpl;

/**
 * Servlet implementation class CalculateNetSalary
 */
@WebServlet("/CalculateNetSalary")
public class CalculateNetSalary extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static AssociateDAO associateDAO = new AssociateDAOImpl();
	public CalculateNetSalary() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateID = Integer.parseInt(request.getParameter("associateID"));
		Associate associate = associateDAO.findOne(associateID);
		if (associate==null) {
			RequestDispatcher rd=request.getRequestDispatcher("calculateSalaryPage.jsp");
			request.setAttribute("salary", "Enter valid Associate ID");
			rd.forward(request, response);
		}
		else {
			double netSalary = calculateNetSalary(associate);
			RequestDispatcher rd=request.getRequestDispatcher("calculateSalaryPage.jsp");
			request.setAttribute("salary", "The Net Salary is: Rs. " + netSalary);
			rd.forward(request, response);
		}
	}

	public static double calculateNetSalary(Associate associate) {
		associate.getSalary().setHra(0.3 * associate.getSalary().getBasicSalary());
		associate.getSalary().setOtherAllowance(0.2 * associate.getSalary().getBasicSalary());
		associate.getSalary().setPersonalAllowance(0.2 * associate.getSalary().getBasicSalary());
		associate.getSalary().setConveyenceAllowance(0.25 * associate.getSalary().getBasicSalary());
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary() + associate.getSalary().getHra() + associate.getSalary().getOtherAllowance() + associate.getSalary().getPersonalAllowance() + associate.getSalary().getConveyenceAllowance());
		double annualGrossSalary = associate.getSalary().getGrossSalary() * 12;
		//Tax Calculation
		double netSalaryAfterInvesting = annualGrossSalary - ((associate.getYearlyInvestmentUnder80C()>(150000-(associate.getSalary().getEpf()*12)-(associate.getSalary().getCompanyPf()*12))?(150000):(associate.getYearlyInvestmentUnder80C() + (associate.getSalary().getEpf()*12) +(associate.getSalary().getCompanyPf()*12))));
		double annualTax = 0;
		if (netSalaryAfterInvesting <= 250000) annualTax = 0;
		else if (netSalaryAfterInvesting>250000 && netSalaryAfterInvesting<= 500000) annualTax = (netSalaryAfterInvesting - 250000) * 0.05;
		else if (netSalaryAfterInvesting>500000 && netSalaryAfterInvesting<=1000000) annualTax = (netSalaryAfterInvesting- 500000) * 0.2 + 250000 * 0.05;
		else annualTax = (netSalaryAfterInvesting - 1000000) * 0.3 + 500000 * 0.2 + 250000*0.05;
		double monthlyTax = annualTax / 12;
		associate.getSalary().setMonthlyTax(monthlyTax);
		associate.getSalary().setNetSalary(Math.round(associate.getSalary().getGrossSalary() - monthlyTax));
		associateDAO.update(associate);
		return associate.getSalary().getNetSalary();
	}
}
