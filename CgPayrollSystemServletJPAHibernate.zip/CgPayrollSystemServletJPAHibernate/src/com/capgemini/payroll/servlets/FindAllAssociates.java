package com.capgemini.payroll.servlets;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.daoservices.AssociateDAO;
import com.capgemini.payroll.daoservices.AssociateDAOImpl;

@WebServlet("/FindAllAssociates")
public class FindAllAssociates extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AssociateDAO associateDAO = new AssociateDAOImpl();
       
    public FindAllAssociates() {
        super();
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Associate> associateList = new ArrayList<>();
		associateList = associateDAO.findAll();
		if (associateList != null) {
			RequestDispatcher rd = request.getRequestDispatcher("retrieveAllAssociatesPage.jsp");
			request.setAttribute("associateList", associateList);
			rd.forward(request, response);
		}
	}

}
