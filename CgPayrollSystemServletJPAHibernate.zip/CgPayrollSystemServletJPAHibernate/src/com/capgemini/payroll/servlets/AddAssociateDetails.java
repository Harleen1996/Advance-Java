package com.capgemini.payroll.servlets;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.beans.Salary;
import com.capgemini.payroll.daoservices.AssociateDAO;
import com.capgemini.payroll.daoservices.AssociateDAOImpl;
import com.capgemini.payroll.exceptions.InvalidAssociateDetailsException;

/**
 * Servlet implementation class AddAssociateDetails
 */
@WebServlet("/AddAssociateDetails")
public class AddAssociateDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AssociateDAO associateDAO = new AssociateDAOImpl();
	public AddAssociateDetails() {
		super();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		try {
			HttpSession session = request.getSession();
			Associate associate = (Associate) session.getAttribute("associate");
			int yearlyInvestmentUnder80C = Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
			double basicSalary = Double.parseDouble(request.getParameter("basicSalary"));
			double epf = Double.parseDouble(request.getParameter("epf"));
			double companyPf = Double.parseDouble(request.getParameter("companyPf"));
			associate.setSalary(new Salary(basicSalary, epf, companyPf));
			associate.setYearlyInvestmentUnder80C(yearlyInvestmentUnder80C);
			session.setAttribute("associate", associate);
//			boolean validDetails;
//			validDetails = validateAssociateDetails(associate);
//			System.out.println("valid details: " + validDetails);
			associate = associateDAO.save(associate);
			System.out.println(associate);
			session.setAttribute("associate", associate);
			RequestDispatcher rd=request.getRequestDispatcher("registrationSuccessful.jsp");
			rd.forward(request, response);
//		} catch (InvalidAssociateDetailsException e) {
//			System.err.println(e.getMessage());
//		}
	}
}
