package com.capgemini.payroll.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.daoservices.AssociateDAO;
import com.capgemini.payroll.daoservices.AssociateDAOImpl;

/**
 * Servlet implementation class FindAAssociate
 */
@WebServlet("/FindAAssociate")
public class FindAAssociate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private AssociateDAO associateDAO = new AssociateDAOImpl();
	public FindAAssociate() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateID = Integer.parseInt(request.getParameter("associateID"));
		Associate associate = associateDAO.findOne(associateID);
		if (associate==null) {
			RequestDispatcher rd=request.getRequestDispatcher("singleAssociateDetailPage.jsp");
			request.setAttribute("associateDetail", "Enter valid Associate ID");
			rd.forward(request, response);
		}
		else {
			CalculateNetSalary.calculateNetSalary(associate);
			RequestDispatcher rd=request.getRequestDispatcher("singleAssociateDetailPage.jsp");
			String a = "<table style=\"border: 1px solid black; border-radius:12px; border-width: 2px; border-spacing: 15px 4px;\"><tr>\r\n" + 
					"	<td colspan='2'><b>Associate Details</b></tr><tr><td>First Name:</td><td>"+associate.getFirstName()+"</td>\r\n" + 
					"	</tr><tr><td>Last Name:</td><td>"+associate.getLastName()+"</td></tr><tr><td>Designation:</td><td>"+associate.getDesignation()+"</td>\r\n" + 
					"	</tr><tr><td>Department:</td><td>"+associate.getDepartment()+"</td></tr><tr><td>Email Address:</td><td>"+associate.getEmailId()+"</td>\r\n" + 
					"	</tr><tr><td>Pan Card:</td><td>"+associate.getPancard()+"</td></tr><tr></tr><tr><td><b>Bank Details:</b></td>\r\n" + 
					"	</tr><tr><td>Bank Name:</td><td>"+associate.getBankDetail().getBankName()+"</td></tr><tr>\r\n" + 
					"	<td>Bank IFSC Code:</td><td>"+associate.getBankDetail().getIfscCode()+"</td></tr><tr><td>Account Number:</td><td>"+associate.getBankDetail().getAccountNumber()+"</td>\r\n" + 
					"	</tr><tr></tr><tr><td colspan='2'><b>Salary Details:</b></td></tr><tr><td>Basic Salary:</td><td>"+associate.getSalary().getBasicSalary()+"</td>\r\n" + 
					"	</tr><tr><td>Yearly Investment:</td><td>"+associate.getYearlyInvestmentUnder80C()+"</td>\r\n" + 
					"	</tr><tr><td>EPF:</td><td>"+associate.getSalary().getEpf()+"</td></tr><tr><td>CompanyPF:</td><td>"+associate.getSalary().getCompanyPf()+"</td>\r\n" + 
					"	</tr><tr><td>Net Salary:</td><td>"+associate.getSalary().getNetSalary()+"</td></tr></table>";
			request.setAttribute("associateDetail", a);
			rd.forward(request, response);
		}
	}
}
