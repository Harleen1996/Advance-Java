package com.capgemini.payroll.daoservices;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import com.capgemini.payroll.beans.Associate;
import com.capgemini.payroll.util.EntityManagerFactoryProvider;
public class AssociateDAOImpl implements AssociateDAO{
	private EntityManagerFactory factory = EntityManagerFactoryProvider.getEntityManagerFactory();
	@Override
	public Associate save(Associate associate) {
		System.out.println("Hello");
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		System.out.println("investment: " + associate.getSalary().getPersonalAllowance());
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate;
	}

	@Override
	public boolean update(Associate associate) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public Associate findOne(int associateId) {
		EntityManager entityManager = factory.createEntityManager();
		return entityManager.find(Associate.class, associateId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Associate> findAll() {
		EntityManager entityManager = factory.createEntityManager();
		Query query = entityManager.createQuery("from Associate a");
		ArrayList<Associate> list = (ArrayList<Associate>) query.getResultList();
		return list;
	}
}