package com.capgemini.payroll.daoservices;
import java.util.ArrayList;

import com.capgemini.payroll.beans.Associate;

public interface AssociateDAO {
	Associate save(Associate associate);
	boolean update(Associate associate);
	Associate findOne(int associateId);
	ArrayList<Associate> findAll();
}
