package com.capgemini.banking.services;


import java.util.ArrayList;
import java.util.List;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Transaction;
import com.capgemini.banking.daoservices.AccountDAO;
import com.capgemini.banking.daoservices.AccountDAOImpl;
import com.capgemini.banking.exceptions.AccountBlockedException;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.exceptions.InsufficientAmountException;
import com.capgemini.banking.exceptions.InvalidAccountTypeException;
import com.capgemini.banking.exceptions.InvalidAmountException;
import com.capgemini.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO = new AccountDAOImpl();
	
	@Override
	public int openAccount(String accountType, float initBalance, int pinNumber)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
			if (!(accountType.equalsIgnoreCase("Savings") || accountType.equalsIgnoreCase("Current")))
				throw new InvalidAccountTypeException("Invalid account type. Please select among (Savings / Current) account type.");
			if (initBalance<1000)
				throw new InvalidAmountException("Insufficient initial balance. Minimum balance of Rs. 1000 must be added");
			Account account = new Account(accountType, initBalance, pinNumber);
			List<Transaction> transactions = new ArrayList<>();
			transactions.add(new Transaction(initBalance, "Deposit", account));
			account.setTransactions(transactions);
			account = accountDAO.saveAccount(account);
			if (account == null)	throw new BankingServicesDownException("Banking Services are Down. Please try again later.");
			return account.getAccountNo();
	}

	@Override
	public float depositAmount(int accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findOne(accountNo);
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			account = accountDAO.depositAmountToAccount(accountNo, amount);
			//if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			return account.getAccountBalance(); 	
	}

	@Override
	public float withdrawAmount(int accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findOne(accountNo);
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			if (account.getPinNumber()!=pinNumber)		throw new InvalidPinNumberException("The pin entered is invalid. Please enter a valid pin");
			if (account.getAccountBalance()-amount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			account = accountDAO.withdrawFromAccount(accountNo, amount, pinNumber);
			return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(int accountNoTo, int accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
			if (accountDAO.findOne(accountNoTo)==null)	throw new AccountNotFoundException("The Receipent's Account does not exists");
			if (accountDAO.findOne(accountNoFrom)==null)	throw new AccountNotFoundException("The Sender Account does not exists");
			if (accountDAO.fetchAccountStatus(accountNoFrom).getStatus().equalsIgnoreCase("Blocked"))	throw new AccountBlockedException("The sender account is blocked.");
			if (accountDAO.findOne(accountNoFrom).getAccountBalance()-transferAmount<1000)	throw new InsufficientAmountException("The transaction got failed due to insufficient balance in the account.");
			withdrawAmount(accountNoFrom, transferAmount, pinNumber);
			depositAmount(accountNoTo, transferAmount);
			return true;
	}

	@Override
	public Account getAccountDetails(int accountNo) throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.findOne(accountNo);
			if (account == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException, AccountNotFoundException {
		List<Account> accounts = accountDAO.findAllAccounts();
		if (accounts == null)		throw new AccountNotFoundException("No Accounts Found!");
		return accounts;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
			List<Transaction> transactions = accountDAO.fetchAllTransactions(accountNo);
			if (transactions == null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return transactions;
	}

	@Override
	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
			Account account =  accountDAO.fetchAccountStatus(accountNo);
			if (account == null) throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			if (account.getStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("The account is blocked. Please contact the customer care to unblock the account");
			return account.getStatus();
	}
	
	@Override
	public boolean changeAccountPin(int accountNo, int pin) throws AccountNotFoundException, BankingServicesDownException{
			Account account =  accountDAO.changePIN(accountNo, pin);
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");	
			return true;
	}

	@Override
	public boolean upblockAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
			Account account = accountDAO.setAccountStatus(accountNo, "Active");
			if (account==null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			return true;
	}

	@Override
	public boolean deactivateAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
			if (accountDAO.findOne(accountNo)== null)	throw new AccountNotFoundException("There is no account with the provided account number. Enter a valid account number.");
			accountDAO.deactivateAccount(accountNo);
			return true;
	}
}
