package com.capgemini.banking.services;

import java.util.List;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.beans.Transaction;
import com.capgemini.banking.exceptions.AccountBlockedException;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.exceptions.InsufficientAmountException;
import com.capgemini.banking.exceptions.InvalidAccountTypeException;
import com.capgemini.banking.exceptions.InvalidAmountException;
import com.capgemini.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {
	int openAccount(String accountType,float initBalance, int pinNumber)
			throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;

	float depositAmount(int accountNo,float amount)
			throws AccountNotFoundException,BankingServicesDownException, AccountBlockedException;

	float withdrawAmount(int accountNo,float amount,int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException ,AccountBlockedException;

	boolean fundTransfer(int accountNoTo,int accountNoFrom,float transferAmount,int pinNumber)
			throws InsufficientAmountException,AccountNotFoundException,InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException;

	Account getAccountDetails(int accountNo)
			throws  AccountNotFoundException,BankingServicesDownException;

	List<Account> getAllAccountDetails()
			throws BankingServicesDownException, AccountNotFoundException;

	List<Transaction> getAccountAllTransaction(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException;

	public String accountStatus(int accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException;
	
	boolean changeAccountPin(int accountNo, int pin) 
			throws AccountNotFoundException, BankingServicesDownException;
	
	boolean upblockAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException;

	boolean deactivateAccount(int accountNo)
			throws AccountNotFoundException, BankingServicesDownException;
}