package com.capgemini.banking.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.daoservices.AccountDAO;
import com.capgemini.banking.daoservices.AccountDAOImpl;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.services.BankingServices;
import com.capgemini.banking.services.BankingServicesImpl;

@WebServlet("/FindAccount")
public class FindAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BankingServices bankingServices=new BankingServicesImpl();
	
	public FindAccount() {
		super();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			int accountNo = Integer.parseInt(request.getParameter("accountNo"));
			Account account = bankingServices.getAccountDetails(accountNo);
			if (account!=null) {
				RequestDispatcher rd=request.getRequestDispatcher("singleAccountDetailPage.jsp");
				request.setAttribute("account",account);
				rd.forward(request, response);
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AccountNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (BankingServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
