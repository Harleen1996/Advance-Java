package com.capgemini.banking.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.banking.beans.Account;
import com.capgemini.banking.exceptions.AccountNotFoundException;
import com.capgemini.banking.exceptions.BankingServicesDownException;
import com.capgemini.banking.services.BankingServices;
import com.capgemini.banking.services.BankingServicesImpl;

@WebServlet("/AdminGetSingleAccountTransactionsServlet")
public class AdminGetSingleAccountTransactionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BankingServices bankingServices = new BankingServicesImpl();
	public AdminGetSingleAccountTransactionsServlet() { super(); }
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Account account = bankingServices.getAccountDetails(Integer.parseInt(request.getParameter("accountNo")));
			if (account != null) {
				request.setAttribute("requestAccountTransactions", "1");
				request.setAttribute("transactions", account.getTransactions());
				request.getRequestDispatcher("adminPage.jsp").forward(request, response);
			}
		} catch (NumberFormatException | AccountNotFoundException | BankingServicesDownException e) {
			request.setAttribute("errorMessage3", e.getMessage());
			request.getRequestDispatcher("adminPage.jsp").forward(request, response);
		}
	}
}
