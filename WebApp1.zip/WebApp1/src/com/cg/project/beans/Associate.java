package com.cg.project.beans;

import java.util.Arrays;

public class Associate {
	private int associateId;
	private String password,firstName,lastName,department,designation,dob,userName,gender,grad,postGrad,emailAddress,age,address,city,state,pinCode,country;
	private String[]hobbie;
	
	public Associate() {}

	public Associate(int associateId, String password, String firstName,
			String lastName, String department, String designation, String dob,
			String userName, String gender, String grad, String postGrad,
			String emailAddress, String age, String address, String city,
			String state, String pinCode, String country, String[] hobbie) {
		super();
		this.associateId = associateId;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.designation = designation;
		this.dob = dob;
		this.userName = userName;
		this.gender = gender;
		this.grad = grad;
		this.postGrad = postGrad;
		this.emailAddress = emailAddress;
		this.age = age;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.country = country;
		this.hobbie = hobbie;
	}





	public Associate(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}

	public int getAssociateId() {
		return associateId;
	}

	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGrad() {
		return grad;
	}

	public void setGrad(String grad) {
		this.grad = grad;
	}

	public String getPostGrad() {
		return postGrad;
	}

	public void setPostGrad(String postGrad) {
		this.postGrad = postGrad;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String[] getHobbie() {
		return hobbie;
	}

	public void setHobbie(String[] hobbie) {
		this.hobbie = hobbie;
	}

	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", password="
				+ password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", department=" + department + ", designation="
				+ designation + ", dob=" + dob + ", userName=" + userName
				+ ", gender=" + gender + ", grad=" + grad + ", postGrad="
				+ postGrad + ", emailAddress=" + emailAddress + ", age=" + age
				+ ", address=" + address + ", city=" + city + ", state="
				+ state + ", pinCode=" + pinCode + ", country=" + country
				+ ", hobbie=" + Arrays.toString(hobbie) + "]";
	}
	
	


	
	

	
}
