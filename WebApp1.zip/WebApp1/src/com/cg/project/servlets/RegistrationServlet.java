package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		/*PrintWriter out=response.getWriter();
		out.print("<html><body><form method='post'><table>"); 
		out.print("<tr><td>First Name:</td><td><input type='text' name='firstname' required placeholder='First name'></td></tr>");
		out.print("<tr><td>Last Name:</td><td> <input type='text' name='lastname' > </td></tr>");
		out.print("<tr><td>Department:</td><td><input type='text' name='department' ></td></tr>");
		out.print("<tr><td>Designation:</td><td><input type='text' name='designation' ></td> </tr>");
		out.print("<tr><td>DOB: </td><td><input type="text" name="dob"> </td></tr>");
		out.print("<tr><td>Username:</td><td><input type="text" name="username" ></td> </tr>");
		out.print("<tr><td>Password:</td><td><input type="password" name="password" pattern="[A-Za-z0-9]{10}"></td></tr><br> ");
		out.print("  <tr> <td>Hobbies:</td><td> <label><input type="checkbox" >Singing</label><label><input type="checkbox" >Dancing</label><label><input type="checkbox" >Sports</label><label><input type="checkbox" >Acting</label><td></tr>");
			

		<tr>	
			<td>Gender:
			<td><Label><input type="radio" name="gender" id="male">Male</label>
			<Label><input type="radio" name="gender" id="female">Female</label></td></tr>
			

		<tr>
			<td><label>Grad:</label></td>
				<td><select>
					<option>--Select Grad--</option>
					<option>B.E</option>
					<option>B.Com</option>
					<option>B.A</option>
					<option>B.SC</option></tr>
				</select>
				

		<tr>
			<td><label>Post Grad:</label></td>
				<td><select>
					<option>--Select Post Grad--</option>
					<option>M.E</option>
					<option>M.Com</option>
					<option>M.A</option>
					<option>M.SC</option></td>
				</select>

				
		<tr>
		<td>E-mail:</td> 
		<td><input type="email" name="emailaddress"></td></tr>

		<br>
		<tr>
		<td><label>Age:</label></td> 
		<td><input type="number" id="age" ></td></tr>


		<tr>
		<td><label>Address:</label> </td>
		<td><textarea rows=5" maxlength="10"></textarea></td></tr>



		<tr>
		<td>City:</td>
		   <td><input type="text" name="city"> </td></tr>
		   

		   <tr>
		   <td>State:</td>
		   <td><input type="text" name="State"></td> </tr>
		   

		  <tr><td>Pin Code:</td>
		   <td><input type="number" name="pincode" min="100000" max="999999"> </td></tr>
		   

		 <tr><td>Country:</td>
		   <td><input type="text" name="country"> </td></tr>
		   

		<tr><td><label>Resume:</label> </td>
		<td><input type="file" id="resume" ></td></tr>


		 </table>
		 <input type="submit"></input>
		</form>  
		  
		</body> 
		</html>");
		
*/	}

	/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		//String dob=request.getParameter("dob");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
		String strDate="";
		try {
			Date date = dateFormat.parse(request.getParameter("dob"));
			dateFormat = new SimpleDateFormat("dd MMMM yyyy");
			strDate=dateFormat.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String[] hobbie=request.getParameterValues("hobbie");
		String gender=request.getParameter("gender");
		String grad=request.getParameter("grad");
		String postGrad=request.getParameter("postGrad");
		String emailAddress=request.getParameter("emailAddress");
		int age=Integer.parseInt(request.getParameter("age"));
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String pinCode=request.getParameter("pincode");
		String country=request.getParameter("country");
		
		PrintWriter out=response.getWriter();
		
		out.println("<html><body><div align='center'>");
		out.println("<table><tr><td>firstName:"+firstName+"</td></tr>");
		out.println("<tr><td>lastName:"+lastName+"</td></tr>");
		out.println("<tr><td>department:"+department+"</td></tr>");
		out.println("<tr><td>designation:"+designation+"</td></tr>");
		out.println("<tr><td>DOB:"+ strDate +"</td></tr>");
		out.println("<tr><td>userName:"+userName+"</td></tr>");
		out.println("<tr><td>password:"+password+"</td></tr>");
		out.println("<tr><td>hobbie: ");
		for(String s:hobbie)
			out.println(s);
		out.println("</td></tr>");
		
		out.println("<tr><td>Grad:"+grad+"</td></tr>");
		out.println("<tr><td>postGrad:"+postGrad+"</td></tr>");
		out.println("<tr><td>emailAddress:"+emailAddress+"</td></tr>");
		out.println("<tr><td>age:"+age+"</td></tr>");
		out.println("<tr><td>address:"+address+"</td></tr>");
		out.println("<tr><td>city:"+city+"</td></tr>");
		out.println("<tr><td>state:"+state+"</td></tr>");
		out.println("<tr><td>pinCode:"+pinCode+"</td></tr>");
		out.println("<tr><td>country:"+country+"</td></tr></table>");
		
		out.println("</div></body></html>");
		
	}*/

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String dob=request.getParameter("dob");
		
		/*SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
		String strDate="";
		try {
			Date date = dateFormat.parse(request.getParameter("dob"));
			dateFormat = new SimpleDateFormat("dd MMMM yyyy");
			strDate=dateFormat.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String[] hobbie=request.getParameterValues("hobbie");
		String gender=request.getParameter("gender");
		String grad=request.getParameter("grad");
		String postGrad=request.getParameter("postGrad");
		String emailAddress=request.getParameter("emailAddress");
	    String age=request.getParameter("age");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String pinCode=request.getParameter("pincode");
		String country=request.getParameter("country");
		
		Associate associate=new Associate(associateId, password, firstName, lastName, department, designation, dob, userName, gender, grad, postGrad, emailAddress, age, address, city, state, pinCode, country, hobbie);
		RequestDispatcher dispatcher;
		dispatcher=request.getRequestDispatcher("WelcomePage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
}
